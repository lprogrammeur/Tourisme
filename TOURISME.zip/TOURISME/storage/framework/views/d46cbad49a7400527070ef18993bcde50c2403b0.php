

<?php $__env->startSection('contenu'); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <br>

<div class="container-fluid">
<a href="<?php echo e(url('setting')); ?>"><i class="bi bi-arrow-left fs-2"></i></a> <br><br>
<div class="cover-photo">
<img src="<?php echo e(asset('assets/images/moi.jpeg')); ?>" alt="Cover Photo">
<div class="profile-image1">
<img src="<?php echo e(asset('assets/images/moi.jpeg')); ?>" alt="Profile Image">
<label for="profile-image-upload" class="camera-icon">
    <i class="bi bi-camera"></i>
</label>
</div>
<label for="cover-photo-upload" class="camera-icon">
<i class="bi bi-camera"></i>
</label>
</div>
<input id="cover-photo-upload" class="hidden-input" type="file">
<input id="profile-image-upload" class="hidden-input" type="file">

<p><div class="font-medium text-base text-gray-800" id="text"><b></b></div></p>

</div><br>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TOURISME\resources\views/vues/voirgroupe.blade.php ENDPATH**/ ?>