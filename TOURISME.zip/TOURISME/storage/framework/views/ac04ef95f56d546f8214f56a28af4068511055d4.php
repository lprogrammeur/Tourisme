

<?php $__env->startSection('contenu'); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <br>

<div class="container">
    <div class="row g-3">
        <p class="d-flex justify-content-between align-items-center">
            <a href="<?php echo e(url('setting')); ?>"><i class="bi bi-arrow-left fs-2"></i></a> Retrouver des amis
        </p>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TOURISME\resources\views/vues/invitation.blade.php ENDPATH**/ ?>