

<?php $__env->startSection('contenu'); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <br>

<div class="container-fluid">
<div class="cover-photo">
<img src="<?php echo e(asset('assets/images/moi.jpeg')); ?>" alt="Cover Photo">
<div class="profile-image1">
<img src="<?php echo e(asset('assets/images/moi.jpeg')); ?>" alt="Profile Image">
<label for="profile-image-upload" class="camera-icon">
    <i class="bi bi-camera"></i>
</label>
</div>
<label for="cover-photo-upload" class="camera-icon">
<i class="bi bi-camera"></i>
</label>
</div>
<input id="cover-photo-upload" class="hidden-input" type="file">
<input id="profile-image-upload" class="hidden-input" type="file">

<p><div class="font-medium text-base text-gray-800" id="text"><b><?php echo e(Auth::user()->name); ?></b></div></p>

</div><br>


<section>
    <div class="container">
        <div class="row">
            <div class="col-md-2 p-3">
                <div class="card shadow-sr bg-light">
                    <div class="card body text-center">
                        <a href="<?php echo e(url('bord')); ?>" class="text-black">
                            <h6 class="text-center"><i class="bi bi-table fs-4"></i></h6>
                            <div class="card-text">
                                Tableau de bord
                            </div>
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-md-2 p-3">
                <div class="card shadow-sr bg-light">
                    <div class="card body text-center">
                        <a href="" class="text-black">
                            <h6 class="text-center"><i class="bi bi-link-45deg fs-4"></i></h6>
                            <div class="card-text">
                                Partager le profile
                            </div>
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-md-2 p-3">
                <div class="card shadow-sr bg-light">
                    <div class="card body text-center">
                        <a href="<?php echo e(url('modification_profile')); ?>" class="text-black">
                            <h6 class="text-center"><i class="bi bi-pencil fs-4"></i></h6>
                            <div class="card-text">
                                Modifier le profile
                            </div>
                        </a>
                    </div>
                </div>
            </div>

            <div class="col-md-6 p-3">
                <div class="card shadow-sr bg-light">
                    <div class="card body text-center">
                        <a href="<?php echo e(url('ajoutinfo')); ?>" class="text-black">
                            <h6 class="text-center"><i class="bi bi-plus-circle fs-4"></i></h6>
                            <div class="card-text">
                               informations supplémentaires
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> <br><br><br>

<section class="">
        <div class="container pt-4 px-4">
            <div class="row g-3">
                <div class="col-md-4">
                <div class="card shadow-sr">
                    <div class="d-flex align-items-center pt-2">
                        <div class="profile-picture">
                            <img src="<?php echo e(asset('assets/images/moi.jpeg')); ?>" alt="Profile Picture">
                        </div>
                        <span class="text-black"><div class="font-medium text-base text-gray-800"><b><?php echo e(Auth::user()->name); ?></b></div></span>
                    </div>
                    <div class="container">
                        <div class="card-body">
                            <div class="card-text">
                                <p class="text-black">
                                    RESEAU SOCIAL DE TOURISME VOUS AUREZ 
                                    LA POSSIBILITE DE PUBLIER LES SITES TOURISTIQUES 
                                    DANS CE RESEAU SOCIAL <b>TOURISMUS</b>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="container">
                        <img src="<?php echo e(asset('assets/images/moi.jpeg')); ?>" alt="" srcset="" class="card-img-top">
                    </div>

                    <div class="container d-flex justify-content-between">
                        <div class="text-black">
                            <b>1000</b>
                        </div>

                        <div class="text-black">
                            <b>1000</b> commentaires
                        </div>

                        <!-- <div class="text-black">
                            1000
                        </div> -->
                    </div>

                    <div class="d-flex justify-content-between">
                        <a href="<?php echo e(url('/')); ?>" class="p-3 text-black">
                            <i class="bi bi-heart"></i>
                            j'aime
                        </a>

                        <a href="<?php echo e(url('/')); ?>" class="p-3 text-black">
                            <i class="bi bi-chat"></i>
                            commenter
                        </a>

                        <a href="<?php echo e(url('/')); ?>" class="p-3 text-black">
                            <i class="bi bi-share"></i>
                            partager
                        </a>
                    </div>
                </div> <br>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TOURISME\resources\views/vues/profile.blade.php ENDPATH**/ ?>