<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tourismus</title>

     <!-- bootstrap css  -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/icon/font/bootstrap-icons.min.css')); ?>">

     <!-- Style css  -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/style/style.css')); ?>">


    <link rel="icon" href="<?php echo e(asset('assets/images/Mlgo.png')); ?>">
</head>
<body class="bg-lightgray">
    <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid">
       <div class="bg-white">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center pt-2">
                <a href="<?php echo e(url('profile')); ?>">
                    <div class="profile-picture">
                        <img src="<?php echo e(asset('assets/images/moi.jpeg')); ?>" alt="Profile Picture">
                    </div>
                </a>
                <a href="<?php echo e(url('profile')); ?>">
                    <div>
                        <span class="text-black"><div class="font-medium text-base text-gray-800"><b><?php echo e(Auth::user()->name); ?></b></div></span>
                    </div>
                </a>
                <div>
                    <a href=""><i class="bi bi-check2-circle fs-4"></i></a>
                </div>
            </div>
        </div>
       </div>
    </div> <br>

    <section class="bg-white pt-4 px-4">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="card shadow-sm round bg-light">
                        <div class="card-body">
                            <div class="card-text text-center"> <br>
                                <h6 class="text-center"><i class="bi bi-box-arrow-in-left fs-4"></i></h6>
                                <form method="POST" action="<?php echo e(route('logout')); ?>" class="dropdown-item">
                                    <?php echo csrf_field(); ?>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                            this.closest(\'form\').submit();']]); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                            this.closest(\'form\').submit();']); ?>
                                            <span class="text-black"><?php echo e(__('Se deconnecter')); ?></span>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </form>
                            </div>
                        </div>
                    </div> <br>
                </div>
                
                <div class="col-md-3">
                    <div class="card shadow-sm round bg-light">
                        <div class="card-body">
                            <div class="card-text text-center"> <br>
                            <h6 class="text-center"><i class="bi bi-book fs-4"></i></h6>
                            <a href="#" class="p-3 text-black">
                                Langues
                            </a>
                            </div>
                        </div>
                    </div> <br>
                </div>

                <div class="col-md-3">
                    <div class="card shadow-sm round bg-light">
                        <div class="card-body">
                            <div class="card-text text-center">
                            <a href="#" class="p-3 text-black">
                                <h6 class="text-center"><i class="bi bi-box-arrow-in-left fs-4"></i></h6>
                                Se deconnecter
                            </a>
                            </div>
                        </div>
                    </div> <br>
                </div>

                <div class="col-md-3">
                    <div class="card shadow-sm round bg-light">
                        <div class="card-body">
                            <div class="card-text text-center">
                            <a href="" class="p-3 text-black">
                                <h6 class="text-center"><i class="bi bi-box-arrow-in-left fs-4"></i></h6>
                                Se deconnecter
                            </a>
                            </div>
                        </div>
                    </div> <br>
                </div>
            </div>
        </div>
    </section>
    

    <script src="<?php echo e(asset("assets/js/bootstrap.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/main/main.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/js/jquery.min.js")); ?>"></script>
    <script src="<?php echo e(asset("assets/js/bootstrap.bundle.min.js")); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\TOURISME\resources\views/vues/list.blade.php ENDPATH**/ ?>