<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tourisme</title>

     <!-- bootstrap css  -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/icon/font/bootstrap-icons.min.css')); ?>">

     <!-- Style css  -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/style/style.css')); ?>">


    <link rel="icon" href="<?php echo e(asset('assets/images/Mlgo.png')); ?>">
</head>
<body class="bg-Mlgo"> <br><br><br><br><br><br>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="text-center">
                            <img src="<?php echo e(asset('assets/images/Mlgo.png')); ?>" alt="" srcset="" class="round" heigh="50px" width="50px">
                        </div> <br>
                        <div class="card-text">
                            <form action="" method="POST">
                                <?php echo csrf_field(); ?>

                                <label for="" class="form-label">E-Mail <b class="text-danger">*</b></label>
                                <input type="email" class="custom-input form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                placeholder="email" name="email" value="<?php echo e(old('email')); ?>"> 
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br>

                                
                                <label for="" class="form-label">Password <b class="text-danger">*</b></label>
                                <input type="password" class="custom-input form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                placeholder="password" name="password" value="<?php echo e(old('password')); ?>"> 
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><br>

                                <div class="gap-2 d-grid col-md-12">
                                    <button type="submit" class="btn btn-primary">Connexion</button>
                                </div> <br>
                            </form>

                            <div class="d-flex justify-content-between">
                                <span>Pas de compte ?</span>
                                <a href="<?php echo e(url('register')); ?>">Créer un compte !</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\TOURISME\resources\views/auth/login.blade.php ENDPATH**/ ?>