

<?php $__env->startSection('contenu'); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <br>

<div class="container">
    <div class="row g-3 justify-content-center">
        <div class="col-sm-6 col-md-4">
            <form action="" method="POST">
                <?php echo csrf_field(); ?> 

                <input type="text" name="residence" id="" class="form-control bg-transparent border-black shadow-sr"> <br>

                <button type="submit" class="btn btn-primary">ajouter</button>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TOURISME\resources\views/vues/residence.blade.php ENDPATH**/ ?>