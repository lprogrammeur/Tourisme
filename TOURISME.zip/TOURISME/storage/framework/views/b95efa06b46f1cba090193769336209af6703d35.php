

<?php $__env->startSection('contenu'); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <br>

<div class="container">
    <div class="row g-3 justify-content-center">
        <div class="col-sm-12 col-md-6">
            <div class="text-center">
                <h2><a href="<?php echo e(url('profile')); ?>"><i class="bi bi-arrow-left"></i></a> AJOUTER DES INFORMATIONS SUPPLEMENTAIRES</h2>
            </div> <br><br>


            <div><a href="<?php echo e(url('coordonnée')); ?>">Coordonnées</a></div> <br>
            <ul>
                <li>
                    
                </li>
                <hr class="border-bottom">
            </ul> <br>

            <hr class="border-bottom"> <br>

            <div><a href="<?php echo e(url('residence')); ?>">Lieux de résidence</a></div> <br>
            <ul>
                <li>
                    
                </li>
                <hr class="border-bottom">
            </ul> <br>

            <hr class="border-bottom"> <br>

            <div><a href="<?php echo e(url('lien')); ?>">Liens</a></div> <br>
            <ul>
                <li>
                    
                </li>
                <hr class="border-bottom">
            </ul> <br>

            <hr class="border-bottom"> <br>

            <div><a href="<?php echo e(url('biographie')); ?>">Biographie</a></div> <br>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TOURISME\resources\views/vues/ajoutinfo.blade.php ENDPATH**/ ?>