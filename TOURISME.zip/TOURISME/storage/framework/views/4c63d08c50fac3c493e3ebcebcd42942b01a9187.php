<section>
    <div class="navbar__nav fixed-top">
        <div class="container-fluid pt-4 px-4">
            <div class="d-flex justify-content-between align-items-center">
                <h1><span class="font-family text-white text">Tourisme</span></h1>

                
                <div class="profile-picture">
                    <img src="<?php echo e(asset('assets/images/moi.jpeg')); ?>" alt="Profile Picture">
                </div>
            </div> <br><br>
            
            <div class="d-flex justify-content-between align-items-center">
                <a href="<?php echo e(url('index')); ?>" class="text-center text-white">
                    <h3 class="text-white"><i class="bi bi-house fs-4"></i></h3>
                </a>

                <a href="<?php echo e(url('profile')); ?>" class="text-center text-white">
                    <h3 class="text-white"><i class="bi bi-person-circle fs-4"></i></h3>
                </a>

                <a href="<?php echo e(url('voirreel')); ?>" class="text-center text-white">
                    <h3 class="text-white"><i class="bi bi-play-btn fs-4"></i></h3>
                </a>

                
                <div>
                    <div class="dropdown">
                        <a class="dropdown-toggle text-white" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-file-image fs-4 text-white"></i>
                        </a>

                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <li class="text-center"><b>Publier</b></li>
                            <li><hr class="border-bottom"></li>
                            <li><a class="dropdown-item" href="<?php echo e(url('photo')); ?>"><i class="bi bi-pencil-square"></i> Photo</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(url('message')); ?>"><i class="bi bi-envelope"></i> Message</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(url('reel')); ?>"><i class="bi bi-play-btn"></i> Réel</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(url('evenement')); ?>"><i class="bi bi-calendar2-event"></i> Evènement</a></li>
                        </ul>
                    </div>
                </div>

                <a href="<?php echo e(url('setting')); ?>" class="text-center text-white">
                    <h3 class="text-white"><i class="bi bi-gear fs-4"></i></h3>
                </a>

                <a href="<?php echo e(url('notification')); ?>" class="text-center text-white">
                    <h3 class="text-white"><i class="bi bi-bell fs-4"></i></h3>
                </a>

                <a href="<?php echo e(url('chat')); ?>" class="text-center text-white">
                    <h3 class="text-white"><i class="bi bi-chat fs-4"></i></h3>
                </a>

                <a href="<?php echo e(url('galerie')); ?>" class="text-center text-white">
                    <h3 class="text-white"><i class="bi bi-images fs-4"></i></h3>
                </a>

                <a href="<?php echo e(url('search')); ?>" class="text-center text-white">
                    <h3 class="text-white"><i class="bi bi-search fs-4"></i></h3>
                </a>
            </div>
        </div>
    </div>
</section> <br><br><br><br><br><br><br><br><br><br><?php /**PATH C:\xampp\htdocs\TOURISME\resources\views/layouts/nav.blade.php ENDPATH**/ ?>