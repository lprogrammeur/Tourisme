

<?php $__env->startSection('contenu'); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <br>

<div class="container-fluid">
       <div class="">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center pt-2">
                <a href="<?php echo e(url('profile')); ?>">
                    <div class="profile-picture">
                        <img src="<?php echo e(asset('assets/images/moi.jpeg')); ?>" alt="Profile Picture">
                    </div>
                </a>
                <a href="<?php echo e(url('profile')); ?>" class="">
                    <div>
                        <span class=""><div class="font-medium text-base text-gray-800"><?php echo e(Auth::user()->name); ?></div></span>
                    </div>
                </a>
                <div>
                    <div class="dropdown">
                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-check2-circle fs-4"></i>
                        </a>

                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <li><a class="dropdown-item" href="#"><b><?php echo e(Auth::user()->name); ?></b></a></li>
                            <li><a class="dropdown-item" href="#">Another action</a></li>
                            <li><a class="dropdown-item" href="#">Something else here</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
       </div>
    </div> <br>

    <section class="pt-4 px-4">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="card shadow-sr round bg-light">
                        <div class="card-body">
                            <div class="card-text text-center">
                            <h6 class="text-center"><i class="bi bi-moon fs-4"></i></h6>
                            <div class="p-3 text-black toggle-container">
                                <label class="toggle-label">Mode sombre</label>
                                <input type="checkbox" id="toggle-switch">
                            </div>
                            </div>
                        </div>
                    </div> <br>
                </div>
                
                <div class="col-md-3">
                    <div class="card shadow-sr round bg-light">
                        <div class="card-body">
                            <div class="card-text text-center"> <br>
                            <h6 class="text-center"><i class="bi bi-book fs-4"></i></h6>
                            <a href="#" class="p-3 text-black">
                                Langues
                            </a>
                            </div>
                        </div>
                    </div> <br>
                </div>

                <div class="col-md-3">
                    <div class="card shadow-sr round bg-light"> <br>
                        <div class="card-body">
                            <div class="card-text text-center">
                            <h6 class="text-center"><i class="bi bi-people fs-4"></i></h6>
                            <a href="<?php echo e(url('groupe')); ?>" class="p-3 text-black">
                                Groupes
                            </a>
                            </div>
                        </div>
                    </div> <br>
                </div>

                <div class="col-md-3">
                    <div class="card shadow-sr round bg-light"> <br>
                        <div class="card-body">
                            <div class="card-text text-center">
                            <h6 class="text-center"><i class="bi bi-play-btn fs-4"></i></h6>
                            <a href="#" class="p-3 text-black">
                                Videos
                            </a>
                            </div>
                        </div>
                    </div> <br>
                </div>

                <div class="col-md-3">
                    <div class="card shadow-sr round bg-light"> <br>
                        <div class="card-body">
                            <div class="card-text text-center">
                            <h6 class="text-center"><i class="bi bi-people fs-4"></i></h6>
                            <a href="<?php echo e(url('invitation')); ?>" class="p-3 text-black">
                                Decouvrir des personnes
                            </a>
                            </div>
                        </div>
                    </div> <br>
                </div>

                <div class="col-md-3">
                    <div class="card shadow-sr round bg-light"> <br>
                        <div class="card-body">
                            <div class="card-text text-center">
                            <h6 class="text-center"><i class="bi bi-table fs-4"></i></h6>
                            <a href="<?php echo e(url('bord')); ?>" class="p-3 text-black">
                                Tableau de bord
                            </a>
                            </div>
                        </div>
                    </div> <br>
                </div>

                <div class="col-md-3">
                    <div class="card shadow-sr round bg-light"> <br>
                        <div class="card-body">
                            <div class="card-text text-center">
                            <h6 class="text-center"><i class="bi bi-calendar2-event fs-4"></i></h6>
                            <a href="<?php echo e(url('voirevenement')); ?>" class="p-3 text-black">
                                Evènements
                            </a>
                            </div>
                        </div>
                    </div> <br>
                </div>

                <div class="col-md-3">
                    <div class="card shadow-sr round bg-light"> <br>
                        <div class="card-body">
                            <div class="card-text text-center">
                            <h6 class="text-center"><i class="bi bi-play-btn fs-4"></i></h6>
                            <a href="<?php echo e(url('voirreel')); ?>" class="p-3 text-black">
                                Réels
                            </a>
                            </div>
                        </div>
                    </div> <br>
                </div>

                <div class="col-md-12"> <br><br><br><br><br><br><br><br>
                    <div class="card shadow-sr round bg-light">
                        <div class="card-body">
                            <div class="card-text text-center"> <br>
                                <h6 class="text-center"><i class="bi bi-box-arrow-in-left fs-4"></i></h6>
                                <form method="POST" action="<?php echo e(route('logout')); ?>" class="dropdown-item">
                                    <?php echo csrf_field(); ?>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                            this.closest(\'form\').submit();']]); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                            this.closest(\'form\').submit();']); ?>
                                            <span class="text-black"><?php echo e(__('Se deconnecter')); ?></span>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </form>
                            </div>
                        </div>
                    </div> <br>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TOURISME\resources\views/vues/setting.blade.php ENDPATH**/ ?>