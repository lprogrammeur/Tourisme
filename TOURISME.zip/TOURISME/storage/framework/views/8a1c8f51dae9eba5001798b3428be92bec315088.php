

<?php $__env->startSection('contenu'); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <br>

<div class="container">
    <span><h1>Galerie photos tourisme</h1></span> <br><br>

    
    <div class="row">
        <div class="col-sm-6 col-md-3 p-3">

        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TOURISME\resources\views/vues/galerie.blade.php ENDPATH**/ ?>