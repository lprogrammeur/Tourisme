@extends('template')

@section('contenu')

@include('layouts.nav') <br>

<div class="container">
    <span><h1>Galerie photos tourisme</h1></span> <br><br>

    
    <div class="row">
        <div class="col-sm-6 col-md-3 p-3">

        </div>
    </div>
</div>


@endsection