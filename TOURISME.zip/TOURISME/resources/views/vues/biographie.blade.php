@extends('template')

@section('contenu')

@include('layouts.nav') <br>

<div class="container">
    <div class="row g-3 justify-content-center">
        <div class="col-sm-6 col-md-4">
            <form action="" method="POST">
                @csrf 

                <textarea name="bio" id="" cols="5" rows="5" class="form-control shadow-sr border-black bg-transparent"></textarea> <br>

                <button type="submit" class="btn btn-primary">ajouter</button>
            </form>
        </div>
    </div>
</div>

@endsection