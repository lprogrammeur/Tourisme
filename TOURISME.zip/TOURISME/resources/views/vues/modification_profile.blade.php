@extends('template')

@section('contenu')

@include('layouts.nav') <br>

<div class="container">
    <div class="row g-3 justify-content-center">
        <div class="col-sm-12 col-md-6">
            <div class="text-center">
                <h2><a href="{{url('profile')}}"><i class="bi bi-arrow-left"></i></a> MODIFICATION DU PROFILE</h2>
            </div> <br>

            <form action="" method="POST">
                @csrf 

                <input type="text" name="name" id="" value="" class="form-control bg-transparent border-black shadow-sr"> <br><br>

                <input type="text" name="bio" id="" value="" class="form-control bg-transparent border-black shadow-sr"> <br><br>
            </form>
        </div>
    </div>
</div>


@endsection