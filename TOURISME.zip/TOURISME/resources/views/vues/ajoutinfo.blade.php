@extends('template')

@section('contenu')

@include('layouts.nav') <br>

<div class="container">
    <div class="row g-3 justify-content-center">
        <div class="col-sm-12 col-md-6">
            <div class="text-center">
                <h2><a href="{{url('profile')}}"><i class="bi bi-arrow-left"></i></a> AJOUTER DES INFORMATIONS SUPPLEMENTAIRES</h2>
            </div> <br><br>


            <div><a href="{{url('coordonnée')}}">Coordonnées</a></div> <br>
            <ul>
                <li>
                    
                </li>
                <hr class="border-bottom">
            </ul> <br>

            <hr class="border-bottom"> <br>

            <div><a href="{{url('residence')}}">Lieux de résidence</a></div> <br>
            <ul>
                <li>
                    
                </li>
                <hr class="border-bottom">
            </ul> <br>

            <hr class="border-bottom"> <br>

            <div><a href="{{url('lien')}}">Liens</a></div> <br>
            <ul>
                <li>
                    
                </li>
                <hr class="border-bottom">
            </ul> <br>

            <hr class="border-bottom"> <br>

            <div><a href="{{url('biographie')}}">Biographie</a></div> <br>

        </div>
    </div>
</div>

@endsection