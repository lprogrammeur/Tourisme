@extends('template')

@section('contenu')

@include('layouts.nav') <br>

<div class="container">
    <span><h1>Recherches</h1></span>

    <div class="row">
        <div class="col-sm-6 col-md-4 p-3">
            <form action="" method="POST">
                @csrf 

                <input type="search" name="search" id="" class="form-control bg-transparent border-black" placeholder="Recherches"> <br><br>
            </form>
        </div>
    </div>
</div>


@endsection