@extends('template')

@section('contenu')

@include('layouts.nav') <br>

<div class="container">
<div class="row">
            <span><h1>Evènements</h1></span> <br><br>



        <div class="col-sm-6 col-md-4 p-3">
        
        </div>
    </div>
</div>


@endsection