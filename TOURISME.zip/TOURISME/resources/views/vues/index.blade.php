@extends('template')

@section('contenu')

@include('layouts.nav') <br>

<section class="">
        <div class="container pt-4 px-4">
            <div class="row g-3">
                <div class="col-md-4">
                <div class="card shadow-sr">
                    <div class="d-flex align-items-center pt-2">
                        <div class="profile-picture">
                            <img src="{{ asset('assets/images/moi.jpeg') }}" alt="Profile Picture">
                        </div>
                        <span class="text-black"><div class="font-medium text-base text-gray-800"><b>{{ Auth::user()->name }}</b></div></span>
                    </div>
                    <div class="container">
                        <div class="card-body">
                            <div class="card-text">
                                <p class="text-black">
                                    RESEAU SOCIAL DE TOURISME VOUS AUREZ 
                                    LA POSSIBILITE DE PUBLIER LES SITES TOURISTIQUES 
                                    DANS CE RESEAU SOCIAL <b>TOURISMUS</b>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="container">
                        <img src="{{ asset('assets/images/moi.jpeg') }}" alt="" srcset="" class="card-img-top">
                    </div>

                    <div class="container d-flex justify-content-between">
                        <div class="text-black">
                            <b>1000</b>
                        </div>

                        <div class="text-black">
                            <b>1000</b> commentaires
                        </div>

                        <!-- <div class="text-black">
                            1000
                        </div> -->
                    </div>

                    <div class="d-flex justify-content-between">
                        <a href="{{ url('/')}}" class="p-3 text-black">
                            <i class="bi bi-heart"></i>
                            j'aime
                        </a>

                        <a href="{{ url('/')}}" class="p-3 text-black">
                            <i class="bi bi-chat"></i>
                            commenter
                        </a>

                        <a href="{{ url('/')}}" class="p-3 text-black">
                            <i class="bi bi-share"></i>
                            partager
                        </a>
                    </div>
                </div> <br>
                </div>
            </div>
        </div>
    </section>

@endsection