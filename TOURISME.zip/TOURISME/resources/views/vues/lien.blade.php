@extends('template')

@section('contenu')

@include('layouts.nav') <br>

<div class="container">
    <div class="row g-3 justify-content-center">
        <div class="col-sm-6 col-md-4">
            <form action="" method="POST">
                @csrf 

                <input type="text" name="lien" id="" class="form-control bg-transparent border-black shadow-sr" placeholder="https://"> <br>

                <button type="submit" class="btn btn-primary">ajouter</button>
            </form>
        </div>
    </div>
</div>

@endsection