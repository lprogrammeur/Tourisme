@extends('template')

@section('contenu')

@include('layouts.nav') <br>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shodow-sm bg-light">
                <div class="card-body">
                    <div class="card-text">
                        <form action="" method="POST">
                            @csrf 

                            <div class="container">
                                <div class="text-r">
                                    <button type="submit" class="btn btn-primary">publier</button> 
                                </div> <br>

                                <label for="" class="form-label">Ajouter du texte</label>
                                <textarea name="description" id="" cols="5" rows="5" placeholder="Ajouter tu texte" 
                                class="form-control custom-input @error('description') is-invalid @enderror"></textarea>
                                @error('description')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror <br>

                                <label for="" class="form-label">Video</label>
                                <input type="file" class="form-control @error('video') is-invalid @enderror" name="video" 
                                id="uploadInput" accept="video/*" multiple>
                                @error('video')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror <br>

                                <div id="videoContainer"></div> <br>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> <br>


@endsection