@extends('template')

@section('contenu')

@include('layouts.nav') <br>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shodow-sm bg-light">
                <div class="card-body">
                    <div class="card-text">
                        <form action="" method="POST">
                            @csrf 

                            <div class="container">
                                <div class="text-r">
                                    <button type="submit" class="btn btn-primary">publier</button> 
                                </div> <br>

                                <label for="" class="form-label">Ajouter du texte</label>
                                <textarea name="description" id="" cols="5" rows="5" placeholder="Ajouter tu texte" 
                                class="form-control custom-input @error('description') is-invalid @enderror"></textarea>
                                @error('description')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror <br>

                                <label for="" class="form-label">Photo</label>
                                <input type="file" class="form-control @error('file') is-invalid @enderror" name="file" 
                                id="uploadInput" accept="image/*" multiple>
                                @error('file')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror <br>

                                <div id="imageContainer"></div> <br>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> <br>


@endsection