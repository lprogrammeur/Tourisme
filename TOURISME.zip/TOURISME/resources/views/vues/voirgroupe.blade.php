@extends('template')

@section('contenu')

@include('layouts.nav') <br>

<div class="container-fluid">
<a href="{{url('setting')}}"><i class="bi bi-arrow-left fs-2"></i></a> <br><br>
<div class="cover-photo">
<img src="{{ asset('assets/images/moi.jpeg') }}" alt="Cover Photo">
<div class="profile-image1">
<img src="{{ asset('assets/images/moi.jpeg') }}" alt="Profile Image">
<label for="profile-image-upload" class="camera-icon">
    <i class="bi bi-camera"></i>
</label>
</div>
<label for="cover-photo-upload" class="camera-icon">
<i class="bi bi-camera"></i>
</label>
</div>
<input id="cover-photo-upload" class="hidden-input" type="file">
<input id="profile-image-upload" class="hidden-input" type="file">

<p><div class="font-medium text-base text-gray-800" id="text"><b></b></div></p>

</div><br>


@endsection