@extends('template')

@section('contenu')

@include('layouts.nav') <br>

<div class="container">
    <div class="row g-3">
        <h1><a href="{{url('profile')}}"><i class="bi bi-arrow-left"></i></a> Statistiques</h1> <br>

        <div class="col-sm-6 col-md-3 p-3">
            <div class="card shadow-sr bg-light">
                <div class="card-body">
                    <div class="card-text">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="">
                                <b>Couverture</b> <br><br>

                                +2000
                            </div>
                            <i class="bi bi-file-image fs-1"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-3 p-3">
            <div class="card shadow-sr bg-light">
                <div class="card-body">
                    <div class="card-text">
                        <div class="d-flex justify-content-between align-items-center">
                                <div class="">
                                    <b>Profile</b> <br><br>

                                    +2000
                                </div>
                                <i class="bi bi-file-image fs-1"></i>
                            </div>
                        </div>
                    </div>
                </div>
        </div>

        <div class="col-sm-6 col-md-3 p-3">
            <div class="card shadow-sr bg-light">
                <div class="card-body">
                    <div class="card-text">
                        <div class="d-flex justify-content-between align-items-center">
                                <div class="">
                                    <b>J'aimes</b> <br><br>

                                    +2000
                                </div>
                                <i class="bi bi-heart fs-1"></i>
                            </div>
                        </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-3 p-3">
            <div class="card shadow-sr bg-light">
                <div class="card-body">
                    <div class="card-text">
                        <div class="d-flex justify-content-between align-items-center">
                                <div class="">
                                    <b>Commentaires</b> <br><br>

                                    +2000
                                </div>
                                <i class="bi bi-chat fs-1"></i>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div> <br><br>

<div class="container">
    <div class="row g-3">
        <h1>Performances</h1> <br>

        <div class="col-sm-6 col-md-3 p-3">
            <div class="card shadow-sr bg-light">
                <div class="card-body">
                    <div class="card-text">
                        <div class="d-flex justify-content-between align-items-center">
                            Publications
                            <a href="" class="">Show all</a>
                        </div> <br>
                        <canvas id="publication"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-3 p-3">
            <div class="card shadow-sr bg-light">
                <div class="card-body">
                    <div class="card-text">
                        <div class="d-flex justify-content-between align-items-center">
                            Commentaires
                            <a href="" class="">Show all</a>
                        </div> <br>
                        <canvas id="commentaire"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-3 p-3">
            <div class="card shadow-sr bg-light">
                <div class="card-body">
                    <div class="card-text">
                        <div class="d-flex justify-content-between align-items-center">
                            J'aimes
                            <a href="" class="">Show all</a>
                        </div> <br>
                        <canvas id="like"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-3 p-3">
            <div class="card shadow-sr bg-light">
                <div class="card-body">
                    <div class="card-text">
                        <div class="d-flex justify-content-between align-items-center">
                            Vues
                            <a href="" class="">Show all</a>
                        </div> <br>
                        <canvas id="vue"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-12 p-3">
            <div class="card shadow-sr bg-light">
                <div class="card-body">
                    <div class="card-text">
                        <div class="d-flex justify-content-between align-items-center">
                            Calendrier
                            <a href="" class="">Show all</a>
                        </div> <br>
                        <div id="dycalendar"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> <br><br>


@endsection