@extends('template')

@section('contenu')

@include('layouts.nav') <br>

<div class="container">
    <span><h1>Notifications</h1></span> <br><br>

    <div class="row">
        <div class="col-sm-6 col-md-4 p-3">

        </div>
    </div>
</div>


@endsection