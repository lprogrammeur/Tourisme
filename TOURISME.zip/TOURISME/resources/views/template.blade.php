<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tourisme</title>

    <!--=============== LIB ===============-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/3.4.0/remixicon.css" crossorigin="">
    <link rel="stylesheet" href="{{ asset('assets/icon/font/bootstrap-icons.min.css') }}" crossorigin="">
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.css') }}">

    <!--=============== CSS ===============-->
    <link rel="stylesheet" href="{{ asset("assets/style/style.css")}}">
    <link rel="stylesheet" href="{{asset("assets/css/dyCalendar.css")}}">
</head>
<body class="light-mode">


    @yield('contenu')
    


    
    <script src="{{asset("assets/js/bootstrap.min.js")}}"></script>
    <script src="{{asset("assets/js/bootstrap.js")}}"></script>
    <script src="{{asset("assets/main/main.js")}}"></script>
    <script src="{{asset("assets/js/jquery.min.js")}}"></script>
    <script src="{{asset("assets/js/bootstrap.bundle.min.js")}}"></script>
    <script src="{{asset("assets/js/dyCalendar.js")}}"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.full.min.js"></script>
    <script>
        const toggleSwitch = document.getElementById('toggle-switch');
        const currentMode = localStorage.getItem('mode');

        if (currentMode === 'dark') {
            document.body.classList.add('dark-mode');
            toggleSwitch.checked = true;
        }

        toggleSwitch.addEventListener('change', function () {
            if (toggleSwitch.checked) {
                document.body.classList.add('dark-mode');
                localStorage.setItem('mode', 'dark');
            } else {
                document.body.classList.remove('dark-mode');
                localStorage.setItem('mode', 'light');
            }
        });
  </script>

  <script>
    function displayImages(files) {
      var container = document.getElementById("imageContainer");
      container.innerHTML = "";

      for (var i = 0; i < files.length; i++) {
        var file = files[i];
        var reader = new FileReader();

        reader.onload = function(event) {
          var img = new Image();
          img.onload = function() {
            var imageDiv = document.createElement("div");
            imageDiv.classList.add("imageContainer");
            imageDiv.appendChild(img);
            container.appendChild(imageDiv);
          };
          img.src = event.target.result;
        };

        reader.readAsDataURL(file);
      }
    }

    var uploadInput = document.getElementById("uploadInput");
    uploadInput.addEventListener("change", function(event) {
      var files = event.target.files;
      displayImages(files);
    });
  </script>

  <script>
    //Publications Sales Chart
var ctx1 = $("#publication").get(0).getContext("2d");
var myChart1 = new Chart(ctx1, {
    type: "bar",
    data: {
        labels: ["jan", "fev", "mars", "avril", "mai", "juin", "juillet"],
        datasets: [{
                label: "CMR",
                data: [15, 30, 55, 65, 60, 80, 95],
                backgroundColor: "rgba(235, 22, 22, .7)"
            },
            {
                label: "GB",
                data: [8, 35, 40, 60, 70, 55, 75],
                backgroundColor: "rgba(235, 22, 22, .5)"
            },
            {
                label: "CV",
                data: [12, 25, 45, 55, 65, 70, 60],
                backgroundColor: "rgba(235, 22, 22, .3)"
            }
        ]
        },
    options: {
        responsive: true
    }
});
  </script>

  <script>
    var ctx2 = $("#commentaire").get(0).getContext("2d");
var myChart2 = new Chart(ctx2, {
    type: "line",
    data: {
        labels: ["2016", "2017", "2018", "2019", "2020", "2021", "2022"],
        datasets: [{
                label: "Salse",
                data: [15, 30, 55, 45, 70, 65, 85],
                backgroundColor: "rgba(235, 22, 22, .7)",
                fill: true
            },
            {
                label: "Revenue",
                data: [99, 135, 170, 130, 190, 180, 270],
                backgroundColor: "rgba(235, 22, 22, .5)",
                fill: true
            }
        ]
        },
    options: {
        responsive: true
    }
});
  </script>

  <script>
    // Single Line Chart
var ctx3 = $("#like").get(0).getContext("2d");
var myChart3 = new Chart(ctx3, {
    type: "line",
    data: {
        labels: [50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150],
        datasets: [{
            label: "Salse",
            fill: false,
            backgroundColor: "rgba(235, 22, 22, .7)",
            data: [7, 8, 8, 9, 9, 9, 10, 11, 14, 14, 15]
        }]
    },
    options: {
        responsive: true
    }
});
  </script>

  <script>
      calendar = dycalendar.draw({
            target: '#dycalendar',
            type: 'month',
            dayformat: 'full',
            monthformat: 'full',
            highlighttargetdate: true,
            prevnextbutton: 'show'
        });
  </script>

  <script>
    var ctx4 = $("#vue").get(0).getContext("2d");
var myChart4 = new Chart(ctx4, {
    type: "bar",
    data: {
        labels: ["Italy", "France", "Spain", "USA", "Argentina"],
        datasets: [{
            backgroundColor: [
                "rgba(235, 22, 22, .7)",
                "rgba(235, 22, 22, .6)",
                "rgba(235, 22, 22, .5)",
                "rgba(235, 22, 22, .4)",
                "rgba(235, 22, 22, .3)"
            ],
            data: [55, 49, 44, 24, 15]
        }]
    },
    options: {
        responsive: true
    }
});
  </script>

<script>
    function displayVideos(files) {
      var container = document.getElementById("videoContainer");
      container.innerHTML = "";

      for (var i = 0; i < files.length; i++) {
        var file = files[i];
        var reader = new FileReader();

        reader.onload = function(event) {
          var video = document.createElement("video");
          video.controls = true;
          video.autoplay = false;
          video.loop = false;

          video.onloadstart = function() {
            var videoDiv = document.createElement("div");
            videoDiv.classList.add("videoContainer");
            videoDiv.appendChild(video);
            container.appendChild(videoDiv);
          };

          video.src = event.target.result;
        };

        reader.readAsDataURL(file);
      }
    }

    var uploadInput = document.getElementById("uploadInput");
    uploadInput.addEventListener("change", function(event) {
      var files = event.target.files;
      displayVideos(files);
    });
</script>
</body>
</html>