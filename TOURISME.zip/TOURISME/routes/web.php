<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\Auth\RegisteredUserController;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ListController;
use App\Http\Controllers\PhotoController;
use App\Http\Controllers\StorieController;
use App\Http\Controllers\BordController;
use App\Http\Controllers\ModifProfieController;
use App\Http\Controllers\AjoutInfoController;
use App\Http\Controllers\MessageController;
use App\Http\Controllers\ReelController;
use App\Http\Controllers\ResidenceController;
use App\Http\Controllers\LienController;
use App\Http\Controllers\BioController;
use App\Http\Controllers\GroupeController;
use App\Http\Controllers\VoirGroupeController;
use App\Http\Controllers\InvitationController;
use App\Http\Controllers\EvenementController;
use App\Http\Controllers\VoirEvenementController;
use App\Http\Controllers\VoirReelController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\ChatController;
use App\Http\Controllers\SearchController;
use App\Http\Controllers\GalerieController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

// Route::get('/dashboard', function () {
//     return view('dashboard');
// })->middleware(['auth'])->name('dashboard');

// Route::get('/', [AuthenticatedSessionController::class, 'create'])->name('login');
// Route::post('/', [AuthenticatedSessionController::class, 'store']);
// Route::post('logout', [AuthenticatedSessionController::class, 'destroy'])->name('logout');

// Route::get('/register', [RegisteredUserController::class, 'create'])->name('register');
// Route::post('/register', [RegisteredUserController::class, 'store']);

Route::middleware(['auth'])->resource('/', IndexController::class);
Route::middleware(['auth'])->resource('profile', ProfileController::class);
Route::middleware(['auth'])->resource('setting', ListController::class);
Route::middleware(['auth'])->resource('photo', PhotoController::class);
Route::middleware(['auth'])->resource('storie', StorieController::class);
Route::middleware(['auth'])->resource('bord', BordController::class);
Route::middleware(['auth'])->resource('modification_profile', ModifProfieController::class);
Route::middleware(['auth'])->resource('ajoutinfo', AjoutInfoController::class);
Route::middleware(['auth'])->resource('message', MessageController::class);
Route::middleware(['auth'])->resource('reel', ReelController::class);
Route::middleware(['auth'])->resource('coordonnée', CoordonneController::class);
Route::middleware(['auth'])->resource('residence', ResidenceController::class);
Route::middleware(['auth'])->resource('lien', LienController::class);
Route::middleware(['auth'])->resource('biographie', BioController::class);
Route::middleware(['auth'])->resource('groupe', GroupeController::class);
Route::middleware(['auth'])->resource('voirgroupe', VoirGroupeController::class);
Route::middleware(['auth'])->resource('invitation', InvitationController::class);
Route::middleware(['auth'])->resource('evenement', EvenementController::class);
Route::middleware(['auth'])->resource('voirevenement', VoirEvenementController::class);
Route::middleware(['auth'])->resource('voirreel', VoirReelController::class);
Route::middleware(['auth'])->resource('notification', NotificationController::class);
Route::middleware(['auth'])->resource('chat', ChatController::class);
Route::middleware(['auth'])->resource('search', SearchController::class);
Route::middleware(['auth'])->resource('galerie', GalerieController::class);

require __DIR__.'/auth.php';
